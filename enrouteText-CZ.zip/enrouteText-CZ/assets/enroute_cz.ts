<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ" sourcelanguage="en">
<context>
    <name>AltitudeCorrectionDialog</name>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="30"/>
        <source>Set Altimeter</source>
        <translation>Nastavit výškoměr</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="52"/>
        <source>If you have good satellite reception and if know your altitude precisely, you can set the satellite altimeter here.</source>
        <translation>Pokud máte dobrý příjem satelitů a pokud znáte svoji přesnou výšku, můžete zde nastavit satelitní výškoměr.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="62"/>
        <source>Altitude</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="72"/>
        <source>ft AMSL</source>
        <translation>ft AMSL</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="84"/>
        <source>The current raw altimeter reading as reported by the satellite navigation system is %1 AMSL. The corrected altitude is %2 AMSL.</source>
        <translation>Aktuální nekorigovaná výška reportovaná satelitním navigačním systémem je %1 AMSL. Korigovaná výška je %2 AMSL.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="86"/>
        <source>Insufficient satellite reception. Altimeter cannot be set.</source>
        <translation>Nedostatečně kvalitní příjem satelitů. Výškoměr není možné nastavit.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="155"/>
        <source>Altimeter cannot be set</source>
        <translation>Výškoměr není možné nastavit</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="158"/>
        <source>Insufficient satellite reception. Please try again once reception becomes better.</source>
        <translation>Nedostatečně kvalitní příjem satelitů. Prosím zkuste to později až budete mít lepší příjem.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="183"/>
        <source>Really set %1 ft?</source>
        <translation>Skutečně nastavit %1 ft?</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/AltitudeCorrectionDialog.qml" line="186"/>
        <source>The altitude reported by the satellite navigation system is %1 AMSL. That is a big difference.</source>
        <translation>Výška reportovaná satelitním navigačním systémem je %1 AMSL. To je příliš velký rozdíl.</translation>
    </message>
</context>
<context>
    <name>BugReportPage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/BugReportPage.qml" line="29"/>
        <source>Bug Report</source>
        <translation>Reportovat chybu</translation>
    </message>
</context>
<context>
    <name>Downloadable</name>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="57"/>
        <source>downloading … %1% complete</source>
        <translation>staženo ze %1%</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="62"/>
        <source>installed • %1</source>
        <translation>instalováno • %1</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="67"/>
        <source>update available</source>
        <translation>dostupná aktualizace</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="69"/>
        <source>no longer supported</source>
        <translation>již není podporováno</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="71"/>
        <source>not installed</source>
        <translation>není nainstalováno</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="76"/>
        <source>file size unknown</source>
        <translation>neznámá velikost souboru</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="288"/>
        <source>the remote server refused the connection (the server is not accepting requests)</source>
        <translation>vzdálený server přerušil spojení (server neakceptuje požadavky)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="292"/>
        <source>the remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>vzdálený server předčasně ukončil spojení dříve, než byla obdržena a zpracována odpověď</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="297"/>
        <source>the remote host name was not found (invalid hostname)</source>
        <translation>jméno vzdáleného serveru neexistuje (nesprávné jméno)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="301"/>
        <source>the connection to the remote server timed out</source>
        <translation>spojení se vzdáleným serverem vypršelo</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="306"/>
        <source>the operation was canceled via calls to abort() or close() before it was finished</source>
        <translation>operace byla ukončena příkazem k ukončení () nebo zavření() dříve, než byla dokončena</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="310"/>
        <source>the SSL/TLS handshake failed and the encrypted channel could not be established. The sslErrors() signal should have been emitted</source>
        <translation>navázání SSL/TLS spojení selhalo a šifrovaný kanál nemohl být sestaven. Měl by být vyslán signál sslErrors() signál</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="315"/>
        <source>the connection was broken due to disconnection from the network</source>
        <translation>připojení bylo přerušeno kvůli odpojení od sítě</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="319"/>
        <source>the connection was broken due to disconnection from the network or failure to start the network</source>
        <translation>připojení bylo přerušeno kvůli odpojení od sítě nebo kvůli chybě při připojení do sítě</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="324"/>
        <source>the background request is not currently allowed due to platform policy</source>
        <translation>požadavek na pozadí není nyní umožněn kvůli zabezpečení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="328"/>
        <source>while following redirects, the maximum limit was reached</source>
        <translation>při sledování přesměrování bylo dosaženo limitu počtu spojení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="332"/>
        <source>while following redirects, the network access API detected a redirect from a encrypted protocol (https) to an unencrypted one (http)</source>
        <translation>při sledování přesměrování bylo API pro přístup do sítě detekováno přesměrování ze zabezpečeného protokolu (https) na nezabezpečené (http)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="337"/>
        <source>the connection to the proxy server was refused (the proxy server is not accepting requests)</source>
        <translation>připojení k proxy serveru bylo zamítnuto (proxy server neakceptuje požadavky)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="342"/>
        <source>the proxy server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>proxy server předčasně ukončil spojení dříve, než byla obdržena a zpracována odpověď</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="347"/>
        <source>the proxy host name was not found (invalid proxy hostname)</source>
        <translation>proxy server nenalezen (nesprávné jméno proxy serveru)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="351"/>
        <source>the connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>připojení k proxy serveru vypršelo, nebo proxy server včas neodpověděl na zaslaný požadavek</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="356"/>
        <source>the proxy requires authentication in order to honour the request but did not accept any credentials offered (if any)</source>
        <translation>proxy server vyžaduje autentifikaci pro vyřízení požadavku, ale nebyly akceptovány přihlašovací údaje (pokud byly odeslány)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="361"/>
        <source>the access to the remote content was denied (similar to HTTP error 403)</source>
        <translation>přístup ke vzdálenému obsahu byl odepřen (podobné chybě HTTP 403)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="365"/>
        <source>the operation requested on the remote content is not permitted</source>
        <translation>požadovaná operace se vzdáleným obsahem není dovolena</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="369"/>
        <source>the remote content was not found at the server (similar to HTTP error 404)</source>
        <translation>vzdálený obsah nebyl na serveru nalezen (podobné chybě HTTP 404)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="373"/>
        <source>the remote server requires authentication to serve the content but the credentials provided were not accepted (if any)</source>
        <translation>vzdálený server požaduje autentifikaci pro poskytnutí obsahu, ale zaslané přihlašovací údaje nebyly akceptovány (pokud byly odeslány)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="378"/>
        <source>the request needed to be sent again, but this failed for example because the upload data could not be read a second time</source>
        <translation>požadavek bylo nutné zaslat znovu ale ten selhal, protože odesílaná data není možné znovu číst</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="383"/>
        <source>the request could not be completed due to a conflict with the current state of the resource</source>
        <translation>požadavek nemůže být dokončen z důvodu aktuálního stavu dat</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="388"/>
        <source>the requested resource is no longer available at the server</source>
        <translation>požadovaná data již nejsou na serveru dostupná</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="392"/>
        <source>the server encountered an unexpected condition which prevented it from fulfilling the request</source>
        <translation>server se dostal do neočekávaného stavu, který mu zabraňuje vyřídit požadavek</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="398"/>
        <source>the server does not support the functionality required to fulfill the request</source>
        <translation>server nepodporuje funkcionalitu vyžadovanou pro vyřízení požadavku</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="402"/>
        <source>the server is unable to handle the request at this time</source>
        <translation>server není schopen nyní vyřídit požadavek</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="407"/>
        <source>the Network Access API cannot honor the request because the protocol is not known</source>
        <translation>API pro přístup k síti nemůže akceptovat požadavek, protože protokol je neznámý</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="411"/>
        <source>the requested operation is invalid for this protocol</source>
        <translation>požadovaná operace je pro tento protokol nevalidní</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="415"/>
        <source>an unknown network-related error was detected</source>
        <translation>detekována neznámá chyba související se síťovým připojením</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="419"/>
        <source>an unknown proxy-related error was detected</source>
        <translation>detekována neznámá chyba související s proxy serverem</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="423"/>
        <source>an unknown error related to the remote content was detected</source>
        <translation>detekována neznámá chyba související se vzdáleným obsahem</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="427"/>
        <source>a breakdown in protocol was detected (parsing error, invalid or unexpected responses, etc.)</source>
        <translation>detekováno přerušení komunikačního protokolu (chyba parsování, nevalidní nebo neočekávaná odezva atp.)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="432"/>
        <source>an unknown error related to the server response was detected</source>
        <translation>detekována neznámá chyba související s odezvou serveru</translation>
    </message>
    <message>
        <location filename="../../enroute/src/Downloadable.cpp" line="436"/>
        <source>unknown</source>
        <translation>neznámý</translation>
    </message>
</context>
<context>
    <name>FirstRunDialog</name>
    <message>
        <location filename="../../enroute/src/qml/dialogs/FirstRunDialog.qml" line="32"/>
        <source>Accept</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/FirstRunDialog.qml" line="36"/>
        <source>Reject</source>
        <translation>Odmítnout</translation>
    </message>
</context>
<context>
    <name>FlightRoute</name>
    <message>
        <location filename="../../enroute/src/FlightRoute.cpp" line="267"/>
        <source>Cruise speed not specified.</source>
        <translation>Cestovní rychlost nebyla zadána.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/FlightRoute.cpp" line="269"/>
        <source>Fuel consumption not specified.</source>
        <translation>Spotřeba paliva nebyla zadána.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/FlightRoute.cpp" line="273"/>
        <source>Wind speed not specified.</source>
        <translation>Rychlost větru nebyla zadána.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/FlightRoute.cpp" line="276"/>
        <source>Wind direction not specified.</source>
        <translation>Směr větru nebyl zadán.</translation>
    </message>
</context>
<context>
    <name>FlightRouteAddWPPage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRouteAddWPPage.qml" line="30"/>
        <source>Add Waypoint to Route</source>
        <translation>Přidat bod do trasy</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRouteAddWPPage.qml" line="43"/>
        <source>Waypoint Name</source>
        <translation>Jméno bodu</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRouteAddWPPage.qml" line="109"/>
        <source>&lt;h3&gt;Sorry!&lt;/h3&gt;&lt;p&gt;No waypoints available. Please make sure that an aviation map is installed.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Pardon!&lt;/h3&gt;&lt;p&gt;Žádné body nejsou dostupné. Ujistěte se, že je nainstalována letecká mapa.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FlightRoutePage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="31"/>
        <source>Flight Route</source>
        <translation>Letová trasa</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="85"/>
        <source>Move Up</source>
        <translation>Přesunout nahoru</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="96"/>
        <source>Move Down</source>
        <translation>Přesunout dolů</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="107"/>
        <source>Remove</source>
        <translation>Odebrat</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="169"/>
        <source>Reverse Route</source>
        <translation>Obrátit trasu</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="182"/>
        <source>Clear Route</source>
        <translation>Smazat trasu</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="203"/>
        <source>Route</source>
        <translation>Trasa</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="204"/>
        <source>Aircraft and Wind</source>
        <translation>Letadlo a vítr</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="229"/>
        <source>&lt;h2&gt;Empty Route&lt;/h2&gt;&lt;p&gt;Use the button &apos;Add Waypoint&apos; below.&lt;/p&gt;</source>
        <translation>&lt;h2&gt;Prázdná trasa&lt;/h2&gt;&lt;p&gt;Použijte tlačítko &apos;Přidat bod&apos; níže.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="260"/>
        <source>Aircraft</source>
        <translation>Letadlo</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="267"/>
        <source>Cruise Speed</source>
        <translation>Cestovní rychlost</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="282"/>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="309"/>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="336"/>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="372"/>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="399"/>
        <source>undefined</source>
        <translation>nedefinováno</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="294"/>
        <source>Descent Speed</source>
        <translation>Rychlost klesání</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="321"/>
        <source>Fuel consumption</source>
        <translation>Spotřeba paliva</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="338"/>
        <source>l/h</source>
        <translation>l/h</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="350"/>
        <source>Wind</source>
        <translation>Vítr</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="357"/>
        <source>Direction</source>
        <translation>Směr</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="384"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/FlightRoutePage.qml" line="435"/>
        <source>Add Waypoint</source>
        <translation>Přidat bod</translation>
    </message>
</context>
<context>
    <name>InfoPage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/InfoPage.qml" line="30"/>
        <source>About Enroute</source>
        <translation>O Enroute</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/InfoPage.qml" line="47"/>
        <source>Author</source>
        <translation>O autorovi</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/InfoPage.qml" line="50"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
</context>
<context>
    <name>MFM</name>
    <message>
        <location filename="../../enroute/src/qml/items/MFM.qml" line="233"/>
        <source>&lt;p&gt;&lt;strong&gt;There is no aviation map installed.&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;Please open the menu and go to &lt;strong&gt;Settings/Download Maps&lt;/strong&gt;.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;strong&gt;Není nainstalovaná žádná letecká mapa.&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;Nainstalujete ji v menu pomocí&lt;strong&gt;Nastavení/Stáhnout mapy&lt;/strong&gt;.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MapManager</name>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="31"/>
        <source>Download Maps</source>
        <translation>Stáhnout mapy</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="124"/>
        <source>Remove from device</source>
        <translation>Odebrat ze zařízení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="141"/>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="407"/>
        <source>Download Error</source>
        <translation>Chyba stahování</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="142"/>
        <source>&lt;p&gt;Failed to download &lt;strong&gt;%1&lt;/strong&gt;.&lt;/p&gt;&lt;p&gt;Reason: %2.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Stahování přerušeno v &lt;strong&gt;%1&lt;/strong&gt;.&lt;/p&gt;&lt;p&gt;Důvod: %2.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="197"/>
        <source>Update list of maps</source>
        <translation>Aktualizovat seznam map</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="209"/>
        <source>Download all updates…</source>
        <translation>Stáhnout všechny aktualizace...</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="234"/>
        <source>Aviation Maps</source>
        <translation>Letecké mapy</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="237"/>
        <source>Base Maps</source>
        <translation>Základní mapy</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="328"/>
        <source>&lt;h3&gt;Sorry!&lt;/h3&gt;&lt;p&gt;The list of available maps has not yet been downloaded from the server. You can restart the download manually using the item &apos;Update&apos; from the menu.  To find the menu, look for the symbol &apos;&amp;#8942;&apos; at the top right corner of the screen.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Pardon!&lt;/h3&gt;&lt;p&gt;Seznam dostupných map nebyl stažen ze serveru. Stahování můžete ručně zahájit pomocí funkce &apos;Aktualizovat&apos; v menu.  Do menu přejdete pomocí symbolu &apos;&amp;#8942;&apos; v pravém horním rohu aplikace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="355"/>
        <source>&lt;h3&gt;Download in progress…&lt;/h3&gt;&lt;p&gt;Please stand by while we download the list of available maps from the server…&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Probíhá stahování…&lt;/h3&gt;&lt;p&gt;prosím čekejte než bude ze serveru stažen seznam dostupných map…&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/MapManager.qml" line="408"/>
        <source>&lt;p&gt;Failed to download the list of aviation maps.&lt;/p&gt;&lt;p&gt;Reason: %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Nepodařilo se stáhnout seznam dostupných map.&lt;/p&gt;&lt;p&gt;Důvod: %1.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MapPage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/MapPage.qml" line="33"/>
        <source>Moving Map</source>
        <translation>Pohyblivá mapa</translation>
    </message>
</context>
<context>
    <name>MobileAdaptor</name>
    <message>
        <location filename="../../enroute/src/MobileAdaptor.cpp" line="99"/>
        <source>Downloading map data…</source>
        <translation>Stahování mapových dat...</translation>
    </message>
</context>
<context>
    <name>NavBar</name>
    <message>
        <location filename="../../enroute/src/qml/items/NavBar.qml" line="84"/>
        <source>Altitude</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/items/NavBar.qml" line="92"/>
        <source>Ground Speed</source>
        <translation>Rychlost proti zemi</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/items/NavBar.qml" line="99"/>
        <source>Track</source>
        <translation>Kurz</translation>
    </message>
</context>
<context>
    <name>NearbyAirfields</name>
    <message>
        <location filename="../../enroute/src/qml/pages/NearbyAirfields.qml" line="31"/>
        <source>Nearby Airfields</source>
        <translation>Nejbližší letiště</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/NearbyAirfields.qml" line="89"/>
        <source>&lt;h3&gt;Sorry!&lt;/h3&gt;&lt;p&gt;No airfields available. Please make sure that an aviation map is installed.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Pardon!&lt;/h3&gt;&lt;p&gt;Žádná dostupná letiště. Prosím ujistěte se, zda máte nainstalovány letecké mapy.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>ParticipatePage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/ParticipatePage.qml" line="29"/>
        <source>Help to make Enroute better</source>
        <translation>Pomozte Enroute vylepšit</translation>
    </message>
</context>
<context>
    <name>SatNav</name>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="313"/>
        <source>Not installed or access denied</source>
        <translation>Není nainstalováno nebo je nedostupné</translation>
    </message>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="316"/>
        <source>Access denied</source>
        <translation>Přístup odepřen</translation>
    </message>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="319"/>
        <source>Connection to SatNav system lost</source>
        <translation>Ztraceno satelitní GPS spojení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="322"/>
        <source>Unknown error</source>
        <translation>Neznámá chyba</translation>
    </message>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="325"/>
        <source>Waiting for signal</source>
        <translation>Čekám na signál</translation>
    </message>
    <message>
        <location filename="../../enroute/src/SatNav.cpp" line="327"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SatNavStatusDialog</name>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="29"/>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="51"/>
        <source>SatNav Status</source>
        <translation>Stav příjmu satelitů</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="58"/>
        <source>Last Fix</source>
        <translation>Poslední fix</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="61"/>
        <source>Mode</source>
        <translation>Mód</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="62"/>
        <source>Flight</source>
        <translation>Let</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="62"/>
        <source>Ground</source>
        <translation>Země</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="70"/>
        <source>Horizontal</source>
        <translation>Horizontální</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="75"/>
        <source>Latitude</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="78"/>
        <source>Longitude</source>
        <translation>Délka</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="81"/>
        <source>Error Estimate</source>
        <translation>Přibližná chyba</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="84"/>
        <source>Ground Speed</source>
        <translation>Rychlost vůči zemi</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="87"/>
        <source>Track</source>
        <translation>Kurz</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="96"/>
        <source>Vertical</source>
        <translation>Vertikální</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="101"/>
        <source>Altitude (raw)</source>
        <translation>Výška (nekorigovaná)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="104"/>
        <source>Altitude (corrected)</source>
        <translation>Výška (korigovaná)</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/SatNavStatusDialog.qml" line="107"/>
        <source>Geoidal separation</source>
        <translation>Rozdíl geoidu</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="29"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="46"/>
        <source>Moving Map</source>
        <translation>Pohyblivá mapa</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="54"/>
        <source>Hide Airspaces above FL100</source>
        <translation>Skrýt prostory nad FL100</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="55"/>
        <source>Upper airspaces currently hidden</source>
        <translation>Vyšší prostory jsou skryty</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="58"/>
        <source>All airspaces currently shown</source>
        <translation>Zobrazeny všechny letové prostory</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="72"/>
        <source>Download Maps</source>
        <translation>Stáhnout mapy</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="72"/>
        <source>Updates available</source>
        <translation>Dostupné aktualizace</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="87"/>
        <source>System</source>
        <translation>Systém</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="95"/>
        <source>Keep Screen On</source>
        <translation>Držet displej aktivní</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="108"/>
        <source>Current Status</source>
        <translation>Aktuální stav</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/pages/SettingsPage.qml" line="108"/>
        <source>SatNav Status</source>
        <translation>Stav příjmu satelitů</translation>
    </message>
</context>
<context>
    <name>UpdateMapDialog</name>
    <message>
        <location filename="../../enroute/src/qml/dialogs/UpdateMapDialog.qml" line="27"/>
        <source>Map updates available</source>
        <translation>Aktualizace map je dostupná</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/UpdateMapDialog.qml" line="28"/>
        <source>&lt;p&gt;One or several of your installed maps can be updated. The estimated download size is %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Jedna nebo více nainstalovaných map může být aktualizována. Přibližný čas stahování je %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/UpdateMapDialog.qml" line="32"/>
        <source>Update now</source>
        <translation>Aktualizovat</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/UpdateMapDialog.qml" line="36"/>
        <source>Later</source>
        <translation>Později</translation>
    </message>
</context>
<context>
    <name>WaypointDescription</name>
    <message>
        <location filename="../../enroute/src/qml/dialogs/WaypointDescription.qml" line="237"/>
        <source>mailto:stefan.kebekus@gmail.com?subject=Enroute, Error Report &amp;body=Thank you for suggesting a correction in the map data. Please describe the issue here.</source>
        <translation>mailto:stefan.kebekus@gmail.com?subject=Enroute, Error Report &amp;body=Děkuji za doporučení k opravě mapových dat. Prosím popište zde problém.</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/WaypointDescription.qml" line="295"/>
        <source>Direct to</source>
        <translation>Přímo na</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/dialogs/WaypointDescription.qml" line="309"/>
        <source>Add to route</source>
        <translation>Přidat do trasy</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="36"/>
        <source>Akaflieg Freiburg - Enroute</source>
        <translation>Akaflieg Freiburg - Enroute</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="101"/>
        <source>enroute flight navigation</source>
        <translation>enroute flight navigation</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="115"/>
        <source>Route</source>
        <translation>Trasa</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="131"/>
        <source>Nearby Airfields</source>
        <translation>Nejbližší letiště</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="151"/>
        <source>Set Altimeter</source>
        <translation>Nastavit výškoměr</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="152"/>
        <source>Insufficient reception</source>
        <translation>Nedostatečný příjem</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="169"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="189"/>
        <source>About Enroute</source>
        <translation>O Enroute</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="204"/>
        <source>Bug report</source>
        <translation>Reportovat chybu</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="220"/>
        <source>Participate</source>
        <translation>Zapojit se</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="243"/>
        <source>Exit</source>
        <translation>Ukončit</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="349"/>
        <source>Do you wish to exit Enroute?</source>
        <translation>Přejete si ukončit Enroute?</translation>
    </message>
    <message>
        <location filename="../../enroute/src/qml/main.qml" line="364"/>
        <source>What&apos;s new …?</source>
        <translation>Co je nového ...?</translation>
    </message>
</context>
</TS>

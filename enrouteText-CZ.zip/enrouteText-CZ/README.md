# enrouteText

This repository hosts text assets and translations for the app [enroute flight navigation](https://github.com/Akaflieg-Freiburg/enroute). Please have a look at the [WIKI pages](https://github.com/Akaflieg-Freiburg/enrouteText/wiki) if you would like to contribute a translation.
